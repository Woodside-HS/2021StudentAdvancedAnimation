//  Particle System  constructor function +++++++++++++++++++++++++++++
function ParticleSystem(){
    //this.x = x;
 
}

  //  placing methods in the prototype 
  ParticleSystem.prototype.run = function(){
    
  }

