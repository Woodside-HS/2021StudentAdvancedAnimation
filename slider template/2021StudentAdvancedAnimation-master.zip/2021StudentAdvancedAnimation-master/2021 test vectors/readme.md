# Test Vector script

test-vectors.html contains a script for testing all the methods of the JSVector class in the file jsvectors.js to be supplied by the student.

All the methods are exercised and the actual results shown in the browser page along with the expected results.

This test script depends on vector methods returning "this" when not returning some scalar value.

This test script also depends a lot on the "toString()" method to display actual results.

The expected values are dependent on the parameters used in the script.
